<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
      integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css"
      integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA=="
      crossorigin="anonymous" referrerpolicy="no-referrer"/>
<link rel="stylesheet" type="text/css" href="{{asset('public/frontend/style.css')}}">

<!-- Takvim -->
<link rel="stylesheet" href="{{asset('public/frontend/vendor/takvim/css/theme-basic.css')}}"/>
<link rel="stylesheet" href="{{asset('public/frontend/vendor/takvim/css/theme-glass.css')}}"/>
<link rel="stylesheet" href="{{asset('public/frontend/vendor/lightbox2/css/lightbox.min.css')}}">
<script src="{{asset('public/frontend/vendor/takvim/bundle.js')}}"></script>
<link rel="stylesheet" type="text/css" href="{{asset('public/frontend/vendor/slick/slick.css')}}"/>
<link rel="stylesheet" type="text/css" href="{{asset('public/frontend/vendor/slick/slick-theme.css')}}"/>
